<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8">
		<title>Crear Nuevo Usuario</title>
		<link rel="stylesheet" type="text/css" href="../css/style.css">
	</head>

	<body>
		<?php
			echo "<h1>Bienvenido, pasaste las validaciones!</h1>";
		?>
	</body>

</html>